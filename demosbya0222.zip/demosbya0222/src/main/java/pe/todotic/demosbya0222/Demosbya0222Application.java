package pe.todotic.demosbya0222;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demosbya0222Application {

	public static void main(String[] args) {
		SpringApplication.run(Demosbya0222Application.class, args);
	}

}
