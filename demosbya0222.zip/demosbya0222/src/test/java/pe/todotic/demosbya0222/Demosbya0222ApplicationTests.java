package pe.todotic.demosbya0222;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosbya0222ApplicationTests {

	@Test
	void contextLoads() {
	}

}
